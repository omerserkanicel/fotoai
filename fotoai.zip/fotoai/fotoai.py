from imageai.Detection import ObjectDetection
def fai_fn():
    detector = ObjectDetection()
    model_path = "videofotoai/fotoai/yolov3 .pt"
    detector.setModelTypeAsYOLOv3()
    detector.setModelPath(model_path)
    detector.loadModel()

    detections = detector.detectObjectsFromImage(
    input_image="videofotoai/fotoai/image.jpeg",
    output_image_path="videofotoai/fotoai/output_image.jpeg",
    minimum_percentage_probability=30)
    sonuc = "videofotoai/fotoai/output_image.jpeg"          
    return sonuc
    